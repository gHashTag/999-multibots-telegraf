---
description: 
globs: 
alwaysApply: false
---
# 🕉️ Техническое Задание (ТЗ): Рефакторинг и Централизация Системы Ценообразования

**Дата:** {current_date}
**Статус:** В разработке

**1. Цель:**

Создать единую, прозрачную, легко управляемую и корректную систему расчета и конфигурации цен на все платные функции бота. Устранить дублирование логики, исправить потенциальные ошибки (работа в минус), централизовать управление наценкой и базовыми ценами.

**2. Проблемы Текущей Системы:**

*   Разрозненная логика расчета цен (ранее в `checkBalanceScene`, `modelsCost`, возможно, в других местах).
*   Неясные константы (например, `interestRate = 0.9`), ведущие к убыткам.
*   Дублирование констант (`starCost`).
*   Базовые цены указаны в разных местах, не всегда ясно, в какой валюте и включают ли они наценку.
*   Отсутствие единой точки для управления наценкой.
*   Сложность добавления/изменения цен для новых функций.

**3. Предлагаемое Решение: Централизованная Система**

Создать четкую структуру с разделением ответственности:

*   **Конфигурация (`src/config/pricing.config.ts`):**
    *   `STAR_COST_USD`: Стоимость 1 звезды в USD (единая константа).
    *   `MARKUP_MULTIPLIER`: Множитель наценки (единая константа, > 1).
    *   `BASE_PRICES_USD`: Объект `Partial<Record<ModeEnum, number>>`, хранящий **базовую** стоимость операции в **USD** для режимов с фиксированной ценой. Для режимов с динамической ценой (steps, modelId) здесь может быть 0 или цена за единицу (требует уточнения для steps).
    *   `(Опционально) CURRENCY_RATES`: Курсы для отображения в других валютах.
*   **Калькулятор (`src/price/calculator.ts`):**
    *   `calculateFinalStarPrice(mode, params)`: **Единственная** функция для расчета **конечной** цены.
        *   Принимает `mode` и `params` (`steps`, `modelId`, `numImages`).
        *   Читает данные из `pricing.config.ts`.
        *   **Логика:**
            1.  Определить базовую цену в USD для `mode`:
                *   Из `BASE_PRICES_USD`, если режим с фиксированной ценой.
                *   Из конфигов моделей (например, `VIDEO_MODELS_CONFIG`) по `modelId`.
                *   Спец. расчет для `steps` (например, `DigitalAvatarBody`).
            2.  Рассчитать конечную цену в **звездах**: `finalStars = (basePriceUSD / STAR_COST_USD) * MARKUP_MULTIPLIER * numImages`.
            3.  Рассчитать цены в других валютах (USD, RUB).
            4.  Вернуть `CostCalculationResult { stars, rubles, dollars }` или `null`.
*   **Хелперы (`src/price/helpers/`):**
    *   Содержат **только** функции для **отображения** цен и сообщений (`sendBalanceMessage`, `sendInsufficientStarsMessage`). **Не содержат** логики расчета.

**4. Задачи Рефакторинга (Детально):**

1.  ✅ **Создать `src/config/pricing.config.ts`:** Определить `STAR_COST_USD`, `MARKUP_MULTIPLIER`, `BASE_PRICES_USD`, `CURRENCY_RATES`. Перенести/проверить базовые цены USD.
2.  ✅ **Создать `src/price/calculator.ts::calculateFinalStarPrice`:** Реализовать базовую логику расчета для фиксированных цен.
3.  ⏳ **Дополнить `calculateFinalStarPrice`:**
    *   Реализовать логику получения базовой цены USD по `modelId` (для `TextToVideo`, `ImageToVideo`, `TextToImage`?)
        *   Импортировать и использовать `VIDEO_MODELS_CONFIG`, `imageModelPrices` (или их рефакторенную версию).
    *   Реализовать логику расчета базовой цены USD для режимов, зависящих от `steps` (`DigitalAvatarBody`, `DigitalAvatarBodyV2`). Определить, что хранится в `BASE_PRICES_USD` для них (цена за шаг?).
4.  🔄 **Обновить `src/scenes/checkBalanceScene.ts`:**
    *   ✅ Удалить старые импорты, константы (`BASE_COSTS`), функции (`calculateModeCost` и др.).
    *   ✅ Использовать `calculateFinalStarPrice` для получения `costResult`.
    *   ✅ Передавать `costResult.stars` в `sendBalanceMessage`, `sendInsufficientStarsMessage`, `enterTargetScene`.
5.  🔄 **Обновить `src/price/helpers/modelsCost.ts`:**
    *   ✅ Удалить все константы и функции расчета цен.
    *   Оставить только `sendInsufficientStarsMessage`, `sendBalanceMessage`.
6.  🔄 **Проверить и Обновить Остальные Места:**
    *   Найти все файлы, импортирующие старые константы/функции цен (`starCost`, `interestRate`, `calculateModeCost`, `modeCosts` и т.д.).
    *   Заменить расчеты на вызов `calculateFinalStarPrice`.
    *   **Примеры мест:**
        *   Визарды генерации (TextToVideo, TextToImage, NeuroPhoto и т.д.) - для отображения цены или предварительной проверки.
        *   Функция `handleBuy`.
        *   Команда `/price`.
        *   Возможно, другие обработчики.
7.  ⚙️ **Реализовать Списание Звезд:** В функции `enterTargetScene` (`checkBalanceScene.ts`) заменить `TODO` на реальный вызов функции `updateUserBalance(userId, -costValue)` (или аналога).
8.  📚 **Обновить Документацию:** Отразить изменения в `.roo/rules/payments-and-subscriptions-unified.md` или создать новый `.roo/rules/pricing_logic.md`.

**5. Затронутые Функции/Режимы (Требуют Проверки Цен):**

*   NeuroPhoto, NeuroPhotoV2
*   NeuroAudio
*   ImageToPrompt
*   Voice
*   TextToSpeech
*   LipSync
*   VoiceToText
*   TextToImage (зависит от модели?)
*   DigitalAvatarBody, DigitalAvatarBodyV2 (зависит от steps)
*   ImageToVideo, TextToVideo (зависит от модели)
*   *Все остальные режимы должны быть бесплатными (цена 0)*

**6. Ожидаемый Результат:**

*   Вся логика расчета цен находится в `calculateFinalStarPrice`.
*   Вся конфигурация цен находится в `pricing.config.ts`.
*   Код стал чище, без дублирования.
*   Наценка применяется корректно (`MARKUP_MULTIPLIER > 1`).
*   Новые функции/модели легко добавлять, изменяя только `pricing.config.ts` и, возможно, `calculateFinalStarPrice`.
