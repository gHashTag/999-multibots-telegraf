---
description: Единственный и главный документ по оплатам подпискам 
globs: 
alwaysApply: false
---
# 🕉️ Единый Манускрипт: Платежи и Подписки 💳✨

**Принцип:** Этот документ – единственный и абсолютный источник истины (`Single Source of Truth`) для всей логики, правил и процессов, связанных с платежами, подписками, балансом (звездами ⭐) и ценообразованием в проекте. Все предыдущие документы и правила на эту тему (`payments-subscriptions-logic.md`, `price-calculation-consistency.md`, `manual-payment-credit.md`, `PAYMENTS_README.md` и т.д.) считаются **устаревшими** и должны ссылаться на этот манускрипт.

**Дата Обновления:** {current_date}

## 1. 🏛️ Архитектура и Источник Истины

*   **Единый Источник:** Таблица Supabase `payments_v2` является **единственным источником истины** для всех финансовых транзакций и определения статуса подписки пользователя.
*   **Таблица `users`:** **Не используется** для хранения статуса подписки, баланса или связанных дат. Содержит только `telegram_id`, `username`, `bot_name` и т.д.
*   **Делегирование Бэкенду (`api-server`):** Обработка **внешних** событий, требующих секретных ключей или сложной логики (например, вебхуки Robokassa Result URL), должна происходить в отдельном сервисе `api-server` ([src/api-server](mdc:src/api-server)). Этот сервис отвечает за проверку подписи, обновление статуса платежа в `payments_v2` и, при необходимости, отправку уведомления пользователю через API бота. URL бэкенда определяется в `src/config/index.ts` (`API_URL`).
*   **Ответственность Бота:** Бот отвечает за инициацию платежа (генерация ссылки Robokassa, вызов `replyWithInvoice` для Stars), создание PENDING записи в `payments_v2`, взаимодействие с пользователем и отображение информации, полученной из `payments_v2`.

## 2. ⚖️ Таблица `payments_v2`: Структура и Назначение Полей

| Поле                | Тип (БД)                    | Описание                                                                                                                                                              | Пример                  | Примечания                                      |
| :------------------ | :-------------------------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :---------------------- | :---------------------------------------------- |
| `id`                | `uuid`                      | Уникальный идентификатор записи (PK)                                                                                                                                    |                         | Генерируется авто                               |
| `inv_id`            | `text`                      | Идентификатор инвойса (может быть ID Robokassa или системный ID). **Должен быть уникальным**.                                                                             | `'431838'`, `'manual-fix...'` | Используется для связи и предотвращения дублей   |
| `telegram_id`       | `text`                      | ID пользователя в Telegram.                                                                                                                                             | `'144022504'`           | Связь с `users.telegram_id`                   |
| `bot_name`          | `text`                      | Имя бота (`botInfo.username`), через которого прошла операция.                                                                                                        | `'ai_koshey_bot'`       |                                                 |
| `amount`            | `numeric`                   | Сумма операции в основной валюте (RUB).                                                                                                                                 | `2999.00`               | Всегда положительное                            |
| `stars`             | `integer`                   | Эквивалент суммы в звездах ⭐.                                                                                                                                         | `1303`                  | Всегда положительное                            |
| `currency`          | `text`                      | Код валюты (`'RUB'`, `'XTR'`).                                                                                                                                        | `'RUB'`                 | Enum `Currency` в коде                          |
| `status`            | `payment_status` (enum)     | Статус платежа (`PENDING`, `COMPLETED`, `FAILED`, `CANCELLED`).                                                                                                         | `'COMPLETED'`           | Enum `PaymentStatus` в коде                     |
| `type`              | `operation_type` (enum)     | **Тип операции. ИСПОЛЬЗОВАТЬ ТОЛЬКО `MONEY_INCOME` или `MONEY_OUTCOME`.**                                                                                             | `'MONEY_INCOME'`        | **КЛЮЧЕВОЕ ПРАВИЛО!** См. раздел 3.             |
| `payment_method`    | `text`                      | Метод оплаты (`'Robokassa'`, `'Telegram'`, `'Manual'`, `'System'`).                                                                                                   | `'Robokassa'`           |                                                 |
| `description`       | `text`                      | Описание операции.                                                                                                                                                      | `'Покупка NEUROBASE'`   |                                                 |
| `metadata`          | `jsonb`                     | Дополнительные данные (nullable).                                                                                                                                       | `{"reason": "manual..."}` |                                                 |
| `created_at`        | `timestamp with time zone`  | Время создания записи.                                                                                                                                                |                         | Устанавливается авто                            |
| `updated_at`        | `timestamp with time zone`  | Время последнего обновления записи.                                                                                                                                     |                         | Обновляется авто                              |
| `subscription_type` | `text`                      | **Тип подписки (`NEUROPHOTO`, `NEUROBASE`...), если `type=MONEY_INCOME` связан с ней.**                                                                              | `'NEUROBASE'`           | `NULL` для расходов (`MONEY_OUTCOME`) и пополнений |
| `service_type`      | `text`                      | **Тип услуги (из `ModeEnum`), если `type=MONEY_OUTCOME`.** (`IMAGE_GENERATION`...)                                                                                    | `'IMAGE_GENERATION'`    | `NULL` для доходов (`MONEY_INCOME`)             |
| `payment_date`      | `timestamp with time zone`  | Дата фактического завершения платежа (nullable).                                                                                                                        |                         | Заполняется при `status = 'COMPLETED'`          |

**Enums:**
*   `payment_status` (БД и Код): `PENDING`, `COMPLETED`, `FAILED`, `CANCELLED`.
*   `operation_type` (БД) / `PaymentType` (Код): **Разрешено использовать ТОЛЬКО `MONEY_INCOME` и `MONEY_OUTCOME`.** В коде `PaymentType` должен содержать только эти два + `REFUND`. *Важно: SQL-функция `get_user_balance` должна игнорировать любые другие значения `operation_type`, которые могут остаться в БД исторически.*

## 3. 📜 Ключевое Правило: Типы Операций (`type`)

*   **Доход (`MONEY_INCOME`):** Любое поступление средств или звезд на баланс пользователя **независимо от источника** (покупка подписки, пополнение баланса, бонус, системное начисление, реферальное вознаграждение) **ДОЛЖНО** записываться с `type = 'MONEY_INCOME'`.
*   **Расход (`MONEY_OUTCOME`):** Любое списание средств или звезд с баланса пользователя за использование сервиса **ДОЛЖНО** записываться с `type = 'MONEY_OUTCOME'`.
*   **Различение Дохода:**
    *   Покупка/Продление подписки: `type = 'MONEY_INCOME'`, `subscription_type` = `'NEUROBASE'` (или другой тип).
    *   Пополнение баланса: `type = 'MONEY_INCOME'`, `subscription_type` = `NULL`.
    *   Бонус/Системное/Реферальное начисление: `type = 'MONEY_INCOME'`, `subscription_type` = `NULL`, `payment_method` = `'Bonus'` / `'System'` / `'Referral'`.
*   **Различение Расхода:**
    *   Использование сервиса: `type = 'MONEY_OUTCOME'`, `service_type` = `'IMAGE_GENERATION'` (или другой `ModeEnum`).
*   **Возвраты (`REFUND`):** Тип `REFUND` может использоваться в коде `PaymentType`, но его обработка в SQL `get_user_balance` требует проверки (должен ли он увеличивать баланс?). Если не используется активно, можно убрать и из кода.

## 4. ⚙️ Основные Функции и Логика

*   **`getUserBalance(telegram_id)`:** ([src/core/supabase/getUserBalance.ts](mdc:src/core/supabase/getUserBalance.ts))
    *   Вызывает SQL-функцию `get_user_balance(user_telegram_id TEXT)`.
    *   SQL-функция **ДОЛЖНА** считать баланс как `SUM(CASE WHEN type = 'MONEY_INCOME' THEN stars ELSE 0 END) - SUM(CASE WHEN type = 'MONEY_OUTCOME' THEN stars ELSE 0 END)`. Игнорировать другие типы.
    *   Использует кэширование на 30 секунд.
    *   Кэш инвалидируется функцией `invalidateBalanceCache(telegram_id)`.
*   **`getUserDetailsSubscription(telegram_id)`:** ([src/core/supabase/getUserDetailsSubscription.ts](mdc:src/core/supabase/getUserDetailsSubscription.ts))
    *   Получает баланс через `getUserBalance`.
    *   Ищет **последнюю** запись в `payments_v2` для данного `telegram_id` со `status = 'COMPLETED'` и `type = 'MONEY_INCOME'` и **не-NULL** значением `subscription_type`.
    *   Определяет `subscriptionType` (Enum) из текстового значения `subscription_type` найденной записи.
    *   Определяет `isSubscriptionActive`:
        *   Если `subscriptionType` = `NEUROTESTER`, то `true`.
        *   Иначе, проверяет, что `payment_date` найденной записи + 30 дней > текущей даты.
    *   Возвращает `{ stars, subscriptionType, isSubscriptionActive, isExist, subscriptionStartDate }`.
*   **`setPayments(params: PaymentParams)`:** ([src/core/supabase/setPayments.ts](mdc:src/core/supabase/setPayments.ts))
    *   Функция для **вставки** записей в `payments_v2`.
    *   **Критично:** Должна вызываться с корректными типами (`MONEY_INCOME`/`MONEY_OUTCOME`) и статусами (`PENDING`, `COMPLETED` и т.д.).
    *   Обрабатывает ошибки вставки, но **не пробрасывает их по умолчанию** (рекомендуется улучшить!).
*   **`calculateFinalPrice(basePriceUSD)`:** ([src/price/helpers/calculateFinalPrice.ts](mdc:src/price/helpers/calculateFinalPrice.ts))
    *   Рассчитывает финальную цену в звездах ⭐: `floor(basePriceUSD / starCost * (1 + interestRate))`.
    *   Константы `starCost` и `interestRate` берутся из `src/price/constants/index.ts`.
*   **Проверка Баланса перед Расходом:** **ОБЯЗАТЕЛЬНО** перед любой операцией расхода (`MONEY_OUTCOME`) нужно вызвать `getUserBalance` и убедиться, что баланс >= стоимости операции. Если нет - отказать в операции, **НЕ СОЗДАВАТЬ** запись `MONEY_OUTCOME`.

## 5. 🌊 Потоки Оплаты (Flows)

### 5.1. Robokassa (Рубли)

1.  **Инициация (Бот):**
    *   Пользователь выбирает товар (подписку/пополнение).
    *   Бот определяет `amount` (RUB) и `stars`.
    *   Бот генерирует уникальный `inv_id`.
    *   Бот вызывает `setPayments` с `status: 'PENDING'`, `type: 'MONEY_INCOME'`, `payment_method: 'Robokassa'`, `currency: 'RUB'`, `subscription_type` (если подписка).
    *   Бот генерирует URL Robokassa (`getInvoiceId`), используя `MERCHANT_LOGIN` и `PASSWORD1`.
    *   Бот отправляет URL пользователю.
2.  **Оплата (Пользователь):** Переходит по URL, оплачивает на стороне Robokassa.
3.  **Подтверждение (`api-server`):**
    *   Robokassa отправляет POST-запрос на Result URL (`/api/robokassa-result`).
    *   `api-server` проверяет подпись запроса, используя `PASSWORD2`.
    *   `api-server` находит в `payments_v2` запись по `inv_id` со статусом `PENDING`.
    *   `api-server` обновляет статус найденной записи на `COMPLETED` и устанавливает `payment_date`.
    *   `api-server` инвалидирует кэш баланса пользователя (нужен механизм!).
    *   `api-server` отправляет уведомление пользователю об успехе через API бота.

### 5.2. Telegram Stars (XTR)

1.  **Инициация (Бот):**
    *   Пользователь выбирает товар (подписку/пополнение).
    *   Бот определяет `amount` (XTR) и тип подписки (если нужно).
    *   Бот вызывает `ctx.replyWithInvoice` с `currency: 'XTR'`, ценой в `prices` (в XTR).
2.  **Подтверждение (Telegram -> Бот):**
    *   Telegram отправляет `pre_checkout_query`. Бот отвечает `ctx.answerPreCheckoutQuery(true)`.
    *   Telegram отправляет `successful_payment`.
3.  **Обработка Успеха (Бот):**
    *   Обработчик `handleSuccessfulPayment` получает `successful_payment`.
    *   Извлекает `total_amount` (XTR), `invoice_payload` (для определения типа подписки/товара).
    *   Вызывает `setPayments` с `status: 'COMPLETED'`, `type: 'MONEY_INCOME'`, `payment_method: 'Telegram'`, `currency: 'XTR'`, `stars: total_amount`, `subscription_type` (если подписка).
    *   Инвалидирует кэш баланса (`invalidateBalanceCache`).
    *   Отправляет уведомление пользователю.

## 6. ⭐ Расчет и Отображение Цен

*   **Расчет (Звезды):** Использовать `calculateFinalPrice`. Константы в `src/price/constants/index.ts`.
*   **Отображение:** Формат `Название Модели (Цена ⭐)`. Использовать эмодзи ⭐ (U+2B50). Применять в генерации клавиатур (`videoModelKeyboard` и др.).

## 7. 🔧 Ручное Зачисление Платежа

*   **Когда:** Автоматика не сработала, есть подтверждение оплаты.
*   **Процесс:**
    1.  Найти `telegram_id`, `bot_name` пользователя (SQL `users`).
    2.  Убедиться, что нет `COMPLETED` записи в `payments_v2` (SQL `payments_v2`).
    3.  Определить количество звезд (`stars_amount`).
    4.  Выполнить `INSERT` в `payments_v2` (SQL):
        *   `status: 'COMPLETED'`
        *   `type: 'MONEY_INCOME'`
        *   `payment_method: 'Manual'`
        *   Заполнить `subscription_type`, если нужно.
        *   Использовать уникальный `inv_id` (e.g., `'manual-fix-...'`).
        *   `payment_date: NOW()` или дата оплаты.
    5.  **Уведомить пользователя** (вручную или через админ-инструмент от имени нужного бота).
    6.  **Уведомить владельца бота** (вручную или через `notifyBotOwners`).
*   **См. также:** `.roo/rules/manual-payment-credit.md` (теперь устарело, логика перенесена сюда).

## 8. 💡 Пути Совершенствования

*   Создать SQL-функцию `manually_credit_payment(...)` для шага 7.4.
*   Создать админ-команду/скрипт для автоматизации всего процесса из шага 7.
*   Улучшить обработку ошибок в `setPayments` (возвращать результат).
*   Убедиться, что SQL `get_user_balance` правильно обрабатывает `REFUND` или убрать `REFUND` из кода.
*   Рассмотреть удаление неиспользуемых `operation_type` из enum базы данных для чистоты (опасно, если есть старые данные).
*   Добавить Foreign Key `payments_v2.telegram_id` -> `users.telegram_id`.

# 🕉️ Правило: Ручное Зачисление Платежа и Уведомление

**Принцип:** Когда автоматические потоки Кармы (вебхуки, обработчики) дают сбой, требуется ручное вмешательство Просветленного (Администратора) для восстановления справедливости и порядка в финансовых потоках.

**Цель:** Обеспечить корректное зачисление подтвержденного, но не обработанного автоматически платежа, активировать подписку и уведомить пользователя и владельца бота.

**Когда Применять:**
*   Получено подтверждение успешной оплаты от платежной системы (Robokassa, Telegram Payments и т.д.).
*   Автоматическая проверка (`payments_v2`) показывает, что соответствующая транзакция НЕ была отмечена как `COMPLETED` или отсутствует вовсе.
*   Пользователь сообщает о проблеме с зачислением.

**Необходимая Информация:**
*   Подтверждение платежа (скриншот, email от платежной системы).
*   Детали платежа: Сумма, Валюта, Тип подписки (если применимо), Email или другие идентификаторы пользователя из платежки.
*   Предполагаемый Username или Telegram ID пользователя (если известен).

## ✨ Священный Ритуал Зачисления

1.  **Идентификация Страждущего (Пользователя):**
    *   **Цель:** Найти `telegram_id` и `bot_name` пользователя в таблице `users`.
    *   **Метод:** Использовать SQL-запрос к таблице `users`, ища по известным данным (username, first_name, last_name), полученным из информации о платеже (например, по части email).
    *   **Пример Запроса (Поиск по имени):**
        ```sql
        SELECT telegram_id, username, first_name, last_name, bot_name
        FROM users
        WHERE first_name ILIKE '%часть_имени_или_email%' OR username ILIKE '%часть_username%';
        ```
    *   **Результат:** Запомнить `telegram_id` и `bot_name`.

2.  **Проверка Книги Судеб (`payments_v2`):**
    *   **Цель:** Убедиться, что платеж действительно не был зачислен автоматически.
    *   **Метод:** Использовать SQL-запрос к `payments_v2` для поиска `COMPLETED` транзакций для найденного `telegram_id` с соответствующей суммой/типом подписки/датой.
    *   **Пример Запроса:**
        ```sql
        SELECT id, status, type, payment_date FROM payments_v2
        WHERE telegram_id = '<НАЙДЕННЫЙ_ID>'
        ORDER BY id DESC LIMIT 10;
        ```
    *   **Результат:** Если нет соответствующей `COMPLETED` записи, переходить к следующему шагу.

3.  **Определение Даров (Количество Звезд):**
    *   **Цель:** Рассчитать или определить корректное количество звезд (`stars_amount`), соответствующее сумме и типу подписки/пополнения.
    *   **Метод:**
        *   Для подписок: Использовать предопределенные значения (например, 1303 для NEUROBASE за 2999 RUB).
        *   Для пополнений: Использовать текущую логику расчета (например, `floor(amount / starCost * (1 + interestRate))`). Проверить константы в `src/price/constants/index.ts`.
    *   **Результат:** Запомнить `stars_amount`.

4.  **Внесение Записи в Летопись (`payments_v2`):**
    *   **Цель:** Создать запись об успешной оплате.
    *   **Метод:** Выполнить SQL `INSERT` в таблицу `payments_v2`.
    *   **Ключевые Поля:**
        *   `telegram_id`: Найденный ID.
        *   `amount`: Сумма платежа.
        *   `stars`: Рассчитанное количество звезд.
        *   `currency`: Валюта платежа ('RUB', 'XTR').
        *   `status`: `'COMPLETED'`
        *   `type`: **ВСЕГДА `'MONEY_INCOME'`** (Независимо от того, подписка это или пополнение).
        *   `subscription_type`: Тип подписки ('NEUROBASE', 'NEUROPHOTO', etc.), если это покупка подписки, иначе `NULL`.
        *   `payment_method`: `'Manual'`
        *   `bot_name`: Найденный `bot_name`.
        *   `inv_id`: Уникальный идентификатор для ручной операции (e.g., `'manual-fix-[оригинальный_ID_заказа]'`).
        *   `description`: Краткое описание (e.g., `'Manual credit for Robokassa order [оригинальный_ID_заказа]'`).
        *   `payment_date`: `NOW()` или фактическое время успешной оплаты.
        *   `metadata` (jsonb, опционально): `'{ "original_order_id": "[ID]", "reason": "Manual fix for failed processing" }'`
    *   **Пример Запроса (Исправленный):**
        ```sql
        INSERT INTO payments_v2
          (telegram_id, amount, stars, currency, status, type, subscription_type, payment_method, bot_name, inv_id, description, payment_date)
        VALUES
          ('[ID]', [Сумма], [Звезды], '[Валюта]', 'COMPLETED', 'MONEY_INCOME', '[ТипПодписки или NULL]', 'Manual', '[ИмяБота]', 'manual-fix-[ID]', 'Manual credit for order [ID]', NOW());
        ```
    *   **Результат:** Запись создана, подписка/баланс пользователя обновлены.

5.  **Благословение Пользователя (Уведомление):**
    *   **Цель:** Сообщить пользователю об успешном зачислении.
    *   **Метод:** **ВНЕ МОИХ ВОЗМОЖНОСТЕЙ.** Требуется действие Администратора или использование специального скрипта/админ-команды.
    *   **Отправитель:** Сообщение должно быть отправлено от имени **правильного `bot_name`**.
    *   **Пример Текста:**
        > "Здравствуйте! Мы успешно обработали вашу оплату подписки [Название Подписки] (заказ [Исходный ID Заказа]). Подписка активирована. Благодарим за ваше терпение! Теперь вам доступны все возможности."
        > (Адаптировать для пополнения баланса)

6.  **Весть Владельцу (Уведомление):**
    *   **Цель:** Информировать владельца бота о ручном вмешательстве.
    *   **Метод:** Использовать существующую функцию `notifyBotOwners(bot_name, details)` из кода (если доступно через скрипт/команду) или уведомить вручную.
    *   **Детали для Уведомления:** `telegram_id`, `username`, `bot_name`, `amount`, `stars`, `subscription_type`, указание на `Manual Credit`.

## 💡 Путь Совершенствования

*   Рассмотреть создание **SQL-функции** `manually_credit_payment(...)` в Supabase для атомарного выполнения шага 4.
*   Рассмотреть создание **административной команды** в боте или отдельного скрипта, который автоматизирует шаги 1-6 (включая отправку уведомлений).
*   
# Уведомления о платежах Telegram Stars

## Контекст проблемы

Уведомления (администратору и владельцам ботов) не отправлялись после успешного платежа с использованием Telegram Stars, инициированного через `starPaymentScene`.

## Основная причина

`starPaymentScene` (@src/scenes/starPaymentScene.ts) оставался активным после того, как пользователь выбрал пакет star, а счет был отправлен обработчиком действий `handleTopUp` (@src/handlers/paymentHandlers/handleTopUp.ts). Когда обновление `successful_payment` пришло из Telegram, активная сцена перехватила его, но не имела конкретного обработчика для этого типа сообщения, что предотвратило выполнение глобального обработчика `bot.on('successful_payment', ...)`.

## Решение

`await ctx.scene.leave()` был добавлен в функцию `handleTopUp` (@src/handlers/paymentHandlers/handleTopUp.ts) сразу после успешной отправки счета (после вызова `await handleBuy(...)`). Это гарантирует, что сцена больше не будет активна, когда поступит обновление `successful_payment`.

## Расположение логики уведомления

Фактическая логика обработки успешного платежа и отправки уведомлений находится в функции `handleSuccessfulPayment` (@src/handlers/paymentHandlers/index.ts или аналогичный путь), которая регистрируется глобально через `bot.on('successful_payment', handleSuccessfulPayment)`, вероятно, в @src/handlers/paymentActions.ts или @src/registerCommands.ts. Этот обработчик вызывает `sendNotification` и `notifyBotOwners`.

**Ключевой вывод:** При отладке отсутствующих обработчиков событий (`bot.on(...)`) проверьте, не перехватывает ли обновление активная сцена. Убедитесь, что сцены выходят (`ctx.scene.leave()`), когда они завершили свое взаимодействие и ожидают внешнего события, обработанного в другом месте.

*Ом Шанти. Да пребудет порядок.* 🙏

*Ом Шанти. Этот Манускрипт - наш Путь к Порядку.* 🙏
