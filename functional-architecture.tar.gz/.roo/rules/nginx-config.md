---
description: 
globs: 
alwaysApply: false
---
# Nginx Configuration Guide

**⚠️ ВНИМАНИЕ! НЕ ИЗМЕНЯТЬ БЕЗ ТРОЙНОГО СОГЛАСОВАНИЯ! ⚠️**
**Каждый параметр критически важен для стабильности!**

/Users/playra/bot-farm/nginx-config/default.conf

Nginx используется как обратный прокси-сервер для нашего приложения.

- **nginx.conf:** Основной файл конфигурации Nginx находится на сервере (`/etc/nginx/nginx.conf`). Его содержимое **КРИТИЧЕСКИ ВАЖНО** и не должно изменяться без крайней необходимости и согласования. Используйте `ssh` для просмотра при необходимости.
- **Конфигурация в Docker:** Настройки Nginx также интегрированы в [docker-compose.yml](mdc:docker-compose.yml) через сервис `nginx-proxy` или аналогичный. Смотрите правило [Docker Configuration Guide](mdc:.roo/rules/docker-config.md) для деталей.

Nginx помогает обрабатывать входящие запросы, распределять нагрузку и обслуживать статические файлы.
