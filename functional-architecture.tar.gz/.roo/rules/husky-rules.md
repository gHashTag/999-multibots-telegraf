---
description: Хаски правила и гитхук. 
globs: 
alwaysApply: false
---
# 🐕 Husky Rules and Git Hooks Configuration

## 📜 Основные файлы
- [.husky/pre-commit](mdc:.husky/pre-commit) - Хук перед коммитом
- [.husky/commit-msg](mdc:.husky/commit-msg) - Хук для проверки сообщений коммита
- [package.json](mdc:package.json) - Конфигурация скриптов
- [.npmrc](mdc:.npmrc) - Настройки npm для Husky

## 🚫 Критические правила

### Pre-commit хук должен:
1. Запускать линтер: `pnpm lint`
2. Проверять типы: `pnpm tsc --noEmit`
3. Запускать тесты: `pnpm test`

### Commit-msg хук должен:
1. Проверять формат сообщения коммита
2. Следовать Conventional Commits
3. Включать эмодзи в начале сообщения

## ⚙️ Настройка окружения
- В `.npmrc` должно быть: `enable-pre-post-scripts=false`
- В `package.json` должен быть скрипт: `"prepare": "husky install"`

## 🔄 Процесс установки
1. Установить husky: `pnpm add -D husky`
2. Включить хуки: `pnpm husky install`
3. Добавить pre-commit хук: `pnpm husky add .husky/pre-commit "pnpm lint && pnpm test"`
4. Добавить commit-msg хук: `pnpm husky add .husky/commit-msg "pnpm commitlint --edit $1"`

## ⚠️ Важные замечания
- Не отключать Husky в CI/CD (кроме установки зависимостей)
- Всегда проверять, что хуки имеют права на выполнение (chmod +x)
- В Docker использовать ENV HUSKY=0 только при сборке
